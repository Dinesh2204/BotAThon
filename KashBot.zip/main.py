import discord
import os
import json
import requests
from keep_alive import keep_alive
from data import get_marks


def get_quote():
  response = requests.get("https://zenquotes.io/api/random")
  json_data = json.loads(response.text)
  quote = json_data[0]['q'] + " -" + json_data[0]['a']
  return(quote)
client = discord.Client()
@client.event
async def on_ready():
    print('We have logged in as{0.user}'.format(client))
@client.event
async def on_message(message):
  if message.author == client.user:
    return
  if message.content.startswith('$hello'):
    await message.channel.send("whats poppin")
  
  if message.content.startswith('$inspire'):
    quote = get_quote()
    await message.channel.send(quote)
  if message.content.startswith('$get_marks'):
    op = get_marks(message.content[11:])
    await message.channel.send(op)
    

keep_alive()

client.run(os.environ.get('TOKEN1'))
