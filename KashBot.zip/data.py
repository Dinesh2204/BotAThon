import pandas as pd
import csv

marks = ""
dict = {}
with open('marks.csv', mode='r') as inp:
    reader = csv.reader(inp)
    dict = {rows[0]:rows[1] for rows in reader}

def get_marks(name):
  marks = dict[name]
  return marks

